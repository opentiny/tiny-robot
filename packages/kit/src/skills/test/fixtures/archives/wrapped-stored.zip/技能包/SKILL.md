---
name: archive-skill
description: Archive fixture
---

# Archive skill