---
name: archive-fixture
description: macOS ZIP fixture
---

# macOS Archive
