---
name: example-skill
description: 用于试用 Skill 导入。
---

# 使用说明

请总结输入文档的要点。
